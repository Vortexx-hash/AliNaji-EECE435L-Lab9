"""Line by line RSS profiling of the original handout workload."""

import time
from memory_profiler import profile


@profile
def slow_function():
    time.sleep(2)
    total = 0
    for i in range(10000):
        total += i ** 2
    return total


@profile
def fast_function():
    total = 0
    for i in range(100):
        total += i ** 2
    return total


@profile
def memory_intensive_function():
    total = 0
    for i in range(10000000):
        total += i ** 2
    return total


def main():
    slow_function()
    fast_function()
    memory_intensive_function()


if __name__ == "__main__":
    main()
